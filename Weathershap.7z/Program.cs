﻿// See https://aka.ms/new-console-template for more information
using Newtonsoft.Json;
using System;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json;

class Program
{
    // ANSI Color Codes
    const string Reset = "\u001B[0m";
    const string Red = "\u001B[31m";
    const string Green = "\u001B[32m";
    const string Yellow = "\u001B[33m";
    const string Blue = "\u001B[34m";
    const string Purple = "\u001B[35m";
    const string Cyan = "\u001B[36m";
    const string Bold = "\u001B[1m";

    // API Configuration
    const string ApiKey = "40e9bec5b53bdd04ff404991fd5bba9e";
    const string BaseUrl = "https://api.openweathermap.org/data/2.5/weather";

    static readonly HttpClient client = new HttpClient();

    static async Task Main(string[] args)
    {
        if (string.IsNullOrEmpty(ApiKey))
        {
            Console.WriteLine(Red + "API key is missing" + Reset);
            return;
        }

        while (true)
        {
            Console.Write(Cyan + "Enter US zip code (or 'q' to quit): " + Reset);
            string zipCode = (Console.ReadLine() ?? "").Trim();

            if (zipCode.ToLower() == "q") break;

            if (!System.Text.RegularExpressions.Regex.IsMatch(zipCode, @"^\d{5}$"))
            {
                Console.WriteLine(Red + "Please enter a valid 5-digit US zip code" + Reset + "\n");
                continue;
            }

            try
            {
                var weatherData = await FetchWeather(zipCode);
                DisplayWeather(weatherData);
            }
            catch (Exception e)
            {
                Console.WriteLine(Red + "Error fetching weather: " + e.Message + Reset);
            }
        }
        Console.WriteLine(Green + "Goodbye!" + Reset);
    }

    static async Task<WeatherData> FetchWeather(string zipCode)
    {
        string url = string.Format("{0}?zip={1},us&units=imperial&appid={2}", BaseUrl, zipCode, ApiKey);
        var response = await client.GetAsync(url);
        response.EnsureSuccessStatusCode();
        string responseBody = await response.Content.ReadAsStringAsync();
        return JsonConvert.DeserializeObject<WeatherData>(responseBody);
    }

    static void DisplayWeather(WeatherData data)
    {
        string weatherColor = GetWeatherColor(data.Weather[0].Main);
        string tempColor = GetTemperatureColor(data.Main.Temp);

        Console.WriteLine("\n" + Bold + Blue + "Weather Report:" + Reset);
        Console.WriteLine(Bold + Blue + "--------------" + Reset);
        Console.WriteLine(Yellow + "Location:" + Reset + " " + Green + data.Name +
                        (!string.IsNullOrEmpty(data.Sys?.Country) ? ", " + data.Sys.Country : "") + Reset);
        Console.WriteLine(Yellow + "Temperature:" + Reset + " " + tempColor +
                        Math.Round(data.Main.Temp) + "°F" + Reset);
        Console.WriteLine(Yellow + "Conditions:" + Reset + " " + weatherColor +
                        data.Weather[0].Description + Reset);
        Console.WriteLine(Yellow + "Humidity:" + Reset + " " + Cyan +
                        data.Main.Humidity + "%" + Reset);
        Console.WriteLine(Yellow + "Wind Speed:" + Reset + " " + Purple +
                        Math.Round(data.Wind.Speed) + " mph" + Reset);
        Console.WriteLine(Bold + Blue + "--------------" + Reset + "\n");
    }

    static string GetWeatherColor(string weatherMain)
    {
        weatherMain = weatherMain.ToLower();
        if (weatherMain.Contains("rain")) return Blue;
        if (weatherMain.Contains("cloud")) return Cyan;
        if (weatherMain.Contains("sun") || weatherMain.Contains("clear")) return Yellow;
        if (weatherMain.Contains("snow")) return Bold + Blue;
        if (weatherMain.Contains("storm")) return Bold + Purple;
        if (weatherMain.Contains("fog") || weatherMain.Contains("mist")) return Cyan;
        return Green;
    }

    static string GetTemperatureColor(float temp)
    {
        if (temp > 85) return Red;
        if (temp > 65) return Yellow;
        if (temp > 32) return Green;
        return Blue;
    }
}

// Data classes to deserialize the JSON response
public class WeatherData
{
    [JsonProperty("name")]
    public string Name { get; set; }

    [JsonProperty("main")]
    public MainData Main { get; set; }

    [JsonProperty("weather")]
    public Weather[] Weather { get; set; }

    [JsonProperty("wind")]
    public Wind Wind { get; set; }

    [JsonProperty("sys")]
    public Sys Sys { get; set; }
}

public class MainData
{
    [JsonProperty("temp")]
    public float Temp { get; set; }

    [JsonProperty("humidity")]
    public int Humidity { get; set; }
}

public class Weather
{
    [JsonProperty("main")]
    public string Main { get; set; }

    [JsonProperty("description")]
    public string Description { get; set; }
}

public class Wind
{
    [JsonProperty("speed")]
    public float Speed { get; set; }
}

public class Sys
{
    [JsonProperty("country")]
    public string Country { get; set; }
}
